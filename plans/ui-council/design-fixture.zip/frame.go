package main

import (
	"fmt"
	"github.com/egoist/mygo/ui"
	"image/png"
	"os"
	"path/filepath"
	"strings"
)

type board struct {
	file, title, context, section, caption string
	cols                                   []string
	rows                                   [][]string
	target                                 string
	props                                  [][]string
	note, action                           string
}

var boards = []board{
	{"01-overview", "设备总览", "mac-mini · macOS · arm64", "本机绑定的项目", "3 个项目   ·   2 项待发布   ·   1 项冲突", []string{"项目", "配置方案", "同步状态"}, [][]string{{"dbark", "development", "1 项冲突"}, {"CtxFerry", "development", "待发布"}, {"notes-kit", "默认", "已同步"}}, "mac-mini", [][]string{{"Git 认证", "已认证 · 今天 14:32"}, {"Infisical", "需要本机登录"}, {"后台同步", "服务运行中"}, {"最后确认", "今天 14:32"}}, "dbark 的测试环境说明在两台设备上分别修改。", "查看冲突"},
	{"02-sync", "同步", "开发工作区 · 分支 main", "记录队列", "共享资料以明文保存于专用私有仓库。", []string{"记录", "项目", "状态"}, [][]string{{"测试环境说明", "dbark", "冲突"}, {"运行手册", "CtxFerry", "待发布"}, {"并行度配置", "dbark", "待发布"}}, "仓库与备份", [][]string{{"私有仓库", "demo / dev-workspace"}, {"分支", "main"}, {"确认的 head", "7a4b102 · 今天 14:32"}, {"历史体积", "18.4 MiB"}, {"最近备份", "今天 09:10"}}, "仅本机资料、checkout 路径和认证材料排除在发布之外。", "比较冲突版本"},
	{"03-conflict", "冲突处理", "同步  /  dbark  /  测试环境说明", "测试环境说明", "Context 文档 · 1 个字段变更 · 合成示例", nil, nil, "", nil, "生成新修订后进入本机待发布队列。", "生成新修订"},
	{"04-project", "项目 · dbark", "dbark  /  development  /  mac-mini", "普通配置", "~/Projects/dbark   ·   当前写入层为设备覆盖", []string{"字段", "生效值", "来源"}, [][]string{{"timeoutSeconds", "90 秒", "设备覆盖"}, {"parallelism", "4", "配置方案"}, {"workingDirectory", "tools", "checkout"}}, "timeoutSeconds", [][]string{{"项目值", "60 秒"}, {"Profile", "继承项目"}, {"设备覆盖", "90 秒 · mac-mini"}, {"checkout", "继承设备"}}, "恢复继承将移除本机覆盖，生效值由 90 秒变为 60 秒。", "恢复为继承…"},
	{"05-secrets", "凭据绑定", "dbark  /  development  /  集成检查", "数据库凭据", "槽位已绑定 test-db-reader，检查当前设备的可用条件。", []string{"条件", "状态", "观察时间"}, [][]string{{"共享槽位绑定", "已绑定", "当前配置"}, {"Infisical 认证", "需登录", "今天 14:35"}, {"条目可读取", "未知", "尚未检查"}, {"资源可达", "TCP 可达", "今天 14:22"}, {"任务测试", "未运行", "—"}}, "test-db-reader", [][]string{{"用途", "集成检查"}, {"资源", "测试数据库"}, {"Provider", "Infisical · dev"}, {"引用路径", "/ctxferry"}, {"条目名", "TEST_DB_READER"}}, "在 mac-mini 完成本机认证后，可重新检查该条目。", "前往本机认证"},
	{"06-fleet", "设备与资源", "dbark  /  测试数据库", "执行环境", "观察按设备独立存放。选择远端设备可查看已有记录。", []string{"设备", "执行环境", "最近观察"}, [][]string{{"mac-mini", "macOS · arm64", "TCP 可达"}, {"legion / Windows", "Windows · x64", "未知"}, {"legion / WSL", "Linux · x64", "未知"}}, "测试数据库", [][]string{{"用途", "集成检查"}, {"业务阶段", "test"}, {"执行设备", "mac-mini"}, {"探测类型", "TCP"}, {"最后观察", "今天 14:22"}}, "探测结果将作为这台设备的一条新观察保存。", "在本机探测"},
	{"07-skills", "Skills", "dbark  /  db-check  /  Codex", "更新计划", "受管复制 · mac-mini · 3 个文件变化", []string{"目标文件", "计划", "本地副本"}, [][]string{{"references/checks.md", "替换（已暂停）", "本地修改"}, {"SKILL.md", "替换", "未修改"}, {"references/ports.md", "新增", "目标不存在"}}, "db-check", [][]string{{"安装目标", "Codex · mac-mini"}, {"共享意图 pin", "3ad021e"}, {"候选 pin", "4b021df"}, {"安装方式", "受管复制"}}, "先比较 checks.md 的本地修改，处理后重新生成计划。", "查看文件差异"},
	{"08-artifacts", "产物", "dbark  /  integration-018", "运行产物", "来源设备 mac-mini · 今天 14:10", []string{"文件", "大小", "内容状态"}, [][]string{{"trace.zip", "7.2 MiB", "仅元数据"}, {"summary.md", "12 KiB", "本机已缓存"}}, "trace.zip", [][]string{{"范围", "full-trace"}, {"来源设备", "mac-mini"}, {"运行", "integration-018"}, {"大小", "7.2 MiB"}, {"内容位置", "来源设备"}}, "该样本超过上传限额。同步目录保留名称、来源和摘要。", "查看来源记录"},
}
var menu = []string{"设备总览", "项目", "设备与资源", "凭据绑定", "Skills", "产物", "同步"}
var paths = []string{"M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z", "M2 7h8l2 2h10v11H2z M3 7V4h7l2 3", "M3 3h18v13H3z M8 21h8 M12 16v5", "M14 3a5 5 0 1 1-2 9l-6 7H3v-4l7-7a5 5 0 0 1 4-5z", "M12 2l10 5-10 5-10-5z M2 12l10 5 10-5 M2 17l10 5 10-5", "M3 6l9-4 9 4v13l-9 3-9-3z M3 6l9 5 9-5 M12 11v11", "M3 10a9 9 0 0 1 16-5l2 3 M21 3v5h-5 M21 14a9 9 0 0 1-16 5l-2-3 M3 21v-5h5", "M5 2h9l5 5v15H5z M14 2v6h5 M8 12h8 M8 16h6", "M3 7h8 M15 7h6 M3 17h3 M10 17h11 M11 4h4v6h-4z M6 14h4v6H6z", "M4 9h16l-2 7H6z M7 9V5h10v4 M2 19q3 3 6 0 4 3 8 0 3 3 6 0", "M3 10a9 9 0 1 1 1 7 M3 4v6h6 M12 7v5l4 2", "M3 4h18v15H3z M6 8l3 3-3 3 M12 14h5"}
var icons []*ui.SVG
var ink = ui.Hex("#193a34")
var mute = ui.Hex("#4c625e")
var line = ui.Hex("#d3ded9")
var pale = ui.Hex("#f0f5f2")
var green = ui.Hex("#255947")

func text(c *ui.Context, s string, n float32) { ui.Text(c, s).FontSize(n).TextColor(ink) }
func small(c *ui.Context, s string)           { ui.Text(c, s).FontSize(13).TextColor(mute) }
func title(c *ui.Context, s string)           { ui.Text(c, s).Bold().FontSize(23).TextColor(ink) }

type scene struct {
	sub, insKind, insTitle, state string
	metrics                       [3][2]string
	info                          [][2]string
	footTitle                     string
	facts                         [][2]string
	desc, button                  string
}

var scenes = []scene{
	{"已绑定项目与本机同步状态", "所选项目", "dbark", "未解决冲突", [3][2]string{{"已绑定项目", "3"}, {"待发布变更", "2"}, {"未解决冲突", "1"}}, [][2]string{{"配置方案", "development"}, {"冲突记录", "测试环境说明"}, {"本机设备", "mac-mini"}, {"远端环境", "legion / WSL"}}, "本机连接", [][2]string{{"Git 认证", "已认证 · 今天 14:32"}, {"Infisical 认证", "需登录 · 今天 14:35"}, {"后台同步", "服务运行中"}}, "此项目有 1 项冲突、1 项待发布。比较两个版本后，可选择要保留的内容。", "比较冲突版本"},
	{"2 项变更可发布，1 项冲突等待解决", "所选记录 · Context", "测试环境说明", "未解决冲突", [3][2]string{{"待发布", "2 项"}, {"冲突", "1 项"}, {"上次确认", "今天 14:32"}}, [][2]string{{"项目", "dbark"}, {"本机设备", "mac-mini"}, {"远端环境", "legion / WSL"}, {"变更字段", "文档摘要"}}, "仓库与备份", [][2]string{{"发布边界", "共享正文以明文存入私有仓库"}, {"私有仓库", "github.com/demo/dev-workspace · 分支 main"}, {"确认的 head", "7a4b102 · 今天 14:32"}, {"历史体积", "18.4 MiB"}, {"最近备份", "今天 09:10"}}, "比较共同基线和两个设备的版本，确认后生成一条本机修订。", "比较冲突版本"},
	{},
	{"当前配置方案包含 3 个普通配置字段", "所选配置字段", "timeoutSeconds", "设备覆盖", [3][2]string{{"项目", "dbark"}, {"配置方案", "development"}, {"Checkout", "~/Projects/dbark"}}, [][2]string{{"全局默认", "未设置"}, {"项目", "60 秒"}, {"配置方案", "继承项目"}, {"设备覆盖", "90 秒"}, {"checkout", "继承设备"}}, "配置上下文", [][2]string{{"当前 checkout", "~/Projects/dbark"}, {"当前配置方案", "development"}, {"写入位置", "mac-mini · 设备覆盖"}}, "仅移除 mac-mini 的 timeoutSeconds 设备覆盖。此设备上继承该层的 checkout 将采用项目值。", "预览恢复继承…"},
	{"逐项检查任务运行需要的条件", "所选条件 · 凭据认证", "Infisical 认证", "需登录", [3][2]string{{"配置方案", "development"}, {"任务", "集成检查"}, {"槽位", "数据库凭据"}}, [][2]string{{"执行设备", "mac-mini"}, {"Provider", "Infisical · dev"}, {"绑定别名", "test-db-reader"}, {"条目引用", "/ctxferry/TEST_DB_READER"}}, "关联资源", [][2]string{{"目标资源", "测试数据库 · test"}, {"最近探测", "mac-mini · TCP 可达 · 今天 14:22"}, {"任务验证", "尚无本次运行结果"}}, "本次认证只影响 mac-mini 的 dev 会话。共享绑定继续指向 test-db-reader。", "在 mac-mini 登录 Infisical"},
	{"按独立执行环境查看观察结果", "所选执行环境", "mac-mini", "TCP 可达", [3][2]string{{"资源", "测试数据库"}, {"业务阶段", "test"}, {"执行环境", "3 个"}}, [][2]string{{"系统", "macOS · arm64"}, {"资源用途", "集成检查"}, {"探测类型", "TCP"}, {"上次观察", "今天 14:22"}}, "访问路线", [][2]string{{"本机路由", "mac-mini → 测试网关 → 测试数据库"}, {"配置来源", "dbark / development"}, {"非秘密端点", "db-test.example:5432"}}, "结果将追加到 mac-mini 的 TCP 观察记录。", "从 mac-mini 探测 TCP"},
	{"选择候选版本，核对本机文件变化", "所选目标文件", "checks.md", "本地修改", [3][2]string{{"安装目标", "Codex"}, {"共享意图 pin", "3ad021e"}, {"候选 pin", "4b021df"}}, [][2]string{{"文件", "references/checks.md"}, {"来源", "db-check"}, {"目标设备", "mac-mini"}, {"本机副本", "与上次写入不同"}}, "本机安装", [][2]string{{"适用 checkout", "~/Projects/dbark"}, {"本机已装 pin", "3ad021e · 受管复制"}, {"计划文件", "1 个新增 · 2 个替换，其中 1 个有本地修改"}, {"确认范围", "共享 pin 更新为 4b021df；安装写入 mac-mini，其他设备独立应用"}}, "处理本地修改后，在「本机安装」中选择「重新扫描并生成计划」。", "比较 checks.md"},
	{"按运行追溯工作产物与内容位置", "所选产物", "trace.zip", "仅元数据", [3][2]string{{"项目", "dbark"}, {"运行", "integration-018"}, {"来源设备", "mac-mini"}}, [][2]string{{"完成范围", "full-trace"}, {"原始大小", "7.2 MiB"}, {"已同步内容", "仅元数据 · 文件未上传"}, {"SHA-256", "2c1d7b8a…4ef9"}, {"本机原文件", "尚未检查"}}, "运行记录", [][2]string{{"来源设备", "mac-mini · 当前设备"}, {"完成时间", "今天 14:10"}, {"归档内容", "2 个条目 · 1 个已缓存"}}, "此文件超过上传限额。先检查来源设备的原文件，再决定能否打开。", "检查本机原文件"},
}

func boxTitle(c *ui.Context, s string) { ui.Text(c, s).Bold().FontSize(17).TextColor(ink) }
func facts(c *ui.Context, items [][2]string) {
	for _, v := range items {
		ui.Row(c).Padding(7, 0).Gap(10).Children(func() {
			ui.Text(c, v[0]).FontSize(13).Width(92).TextColor(mute)
			if v[0] == "Infisical 认证" && strings.HasPrefix(v[1], "需登录") {
				chip(c, "需登录")
				small(c, strings.TrimPrefix(v[1], "需登录 · "))
				return
			}
			field := ui.Text(c, v[1]).FontSize(14).Grow(1).TextColor(ink)
			if technical(v[1]) {
				field.Font("monospace")
			}
		})
	}
}
func technical(s string) bool {
	return strings.Contains(s, "/") && !strings.ContainsAny(s, "的与") || len(s) == 7 && !strings.Contains(s, " ") || strings.Contains(s, ".md") || strings.Contains(s, ".zip") || strings.Contains(s, "TEST_DB") || s == "timeoutSeconds" || s == "workingDirectory" || s == "parallelism" || s == "test-db-reader"
}
func selectVal(c *ui.Context, label, value string, more ...string) {
	opts := append([]string{value}, more...)
	ui.Select(c, &value, opts).Label(label)
}
func chip(c *ui.Context, s string) {
	bg, fg := "#e5eee9", "#235a43"
	switch s {
	case "未解决冲突", "1 项冲突", "冲突":
		bg, fg = "#f6dfd7", "#803224"
	case "本地有修改", "需要处理", "需登录", "存在本地修改", "需处理", "本地修改", "1 个文件有本地修改，更新已暂停":
		bg, fg = "#fff0c9", "#744800"
	case "目标不存在", "设备覆盖", "checkout", "配置方案", "未知", "未运行", "尚未检查", "仅元数据", "—":
		bg, fg = "#eaeef0", "#42545d"
	case "待发布", "更新":
		bg, fg = "#e6edf9", "#345681"
	}
	prefix := ""
	switch s {
	case "未解决冲突", "需要处理", "1 项冲突", "冲突", "需登录", "本地有修改", "本地修改":
		prefix = "!  "
	case "已同步", "TCP 可达", "已绑定", "本机已缓存":
		prefix = "✓  "
	}
	ui.Text(c, prefix+s).FontSize(14).Bold().TextColor(ui.Hex(fg)).Background(ui.Hex(bg)).Padding(3, 8).Radius(5)
}
func ico(c *ui.Context, i int, n float32) { ui.Icon(c, icons[i]).FontSize(n).TextColor(green) }
func conflict(c *ui.Context) {
	const base = "运行前检查服务连通性"
	additions := [...]string{"", "，并记录探测结果。", "，并核对测试环境。"}
	choice := 0 // The board captures the local selection.
	previewText := base + additions[1]
	ui.Column(c).Padding(22, 26).Gap(14).Grow(1).Children(func() {
		ui.Row(c).Gap(10).Children(func() {
			boxTitle(c, "文档摘要")
			small(c, "1 个字段有差异")
			ui.Spacer(c)

		})
		ui.Row(c).Gap(12).AlignItems(ui.Stretch).Children(func() {
			for i, label := range []string{"共同基线", "本机版本", "远端版本"} {
				col := line
				if i == 1 {
					col = green
				}
				ui.Column(c).Basis(0).Grow(1).MinHeight(167).Border(1, col).Radius(8).Padding(16).Gap(9).Children(func() {
					ui.Row(c).Gap(8).Children(func() {
						ico(c, []int{10, 2, 11}[i], 17)
						boxTitle(c, label)
						if i == 1 {
							ui.Spacer(c)
							chip(c, "已选")
						}
					})
					small(c, []string{"mac-mini  ·  11 月 18 日 13:50", "mac-mini  ·  今天 14:18", "legion / WSL  ·  今天 14:21"}[i])
					ui.Text(c, []string{"修订 5bf0321", "修订 891bc42", "修订 c51f5b2"}[i]).Font("monospace").FontSize(12).TextColor(mute)
					ui.Divider(c)
					if i == 0 {
						text(c, base, 15)
					} else {
						ui.Text(c, "＋ 新增").FontSize(13).Bold().TextColor(green)
						ui.Row(c).Gap(0).Children(func() {
							text(c, base, 15)
							ui.Text(c, additions[i]).BorderWidth(0, 0, 0, 2).BorderColor(green).Padding(1, 4).Bold().FontSize(15).TextColor(green).Background(ui.Hex("#c6e6c0"))
						})
					}
				})
			}
		})
		ui.Column(c).FillWidth().Background(pale).Border(1, line).Radius(8).Padding(16, 18).Gap(12).Children(func() {
			ui.Row(c).Gap(20).Children(func() {
				boxTitle(c, "解决方式")
				ui.RadioGroup(c, func() {
					for i, label := range []string{"采用本机", "采用远端", "编辑新版本"} {
						ui.RadioBase(c, &choice, i).Label(label).Gap(6).Children(func() {
							ring := ui.Box(c).Size(16, 16).Radius(8).Border(2, ui.Hex("#687873")).Background(ui.Hex("#ffffff")).Justify(ui.Center).AlignItems(ui.Center)
							if i == choice {
								ring.Border(2, green).Background(green).Children(func() { ui.Box(c).Size(6, 6).Radius(3).Background(ui.Hex("#ffffff")) })
							}
							text(c, label, 14)
						})
					}
				}).Row().Gap(14).Label("解决方式")
			})
			ui.Divider(c)
			ui.Column(c).FillWidth().Background(ui.Hex("#ffffff")).Padding(12, 14).Gap(8).Radius(5).Children(func() {
				ui.Text(c, "结果全文 · mac-mini").Bold().FontSize(14).TextColor(ink)
				text(c, previewText, 16)
			})
			ui.Row(c).Gap(12).Children(func() {
				ui.PrimaryButton(c, "生成本机修订").Padding(9, 16)
				small(c, "保存在本机，等待下一次发布。")
			})
		})
	})
}
func publishPreview(c *ui.Context, open *bool) {
	ui.DialogBase(c, open, func(backdrop, panel ui.Element) {
		backdrop.Background(ui.RGBA(16, 31, 26, .35))
		panel.Width(570).Padding(24).Gap(12).Radius(10).Background(ui.Hex("#ffffff"))
		title(c, "预览待发布变更")
		small(c, "mac-mini → github.com/demo/dev-workspace · 分支 main")
		ui.Divider(c)
		boxTitle(c, "本次发布 · 2 项")
		manualOpen, configOpen := true, false
		ui.Collapsible(c, "CtxFerry / 运行手册", &manualOpen, func() {
			ui.Column(c).Padding(9, 12).Gap(5).Background(pale).Radius(4).Children(func() {
				small(c, "正文变更 · 相对上次确认的版本")
				ui.Text(c, "−  移除　运行集成检查。").FontSize(14).Bold().Padding(4, 7).Background(ui.Hex("#f6e5df")).TextColor(ui.Hex("#773b2d"))
				ui.Text(c, "＋  新增　确认数据库可达后，运行集成检查。").FontSize(14).Bold().Padding(4, 7).Background(ui.Hex("#dfefe4")).TextColor(green)
			})
		})
		ui.Collapsible(c, "dbark / 并行度配置", &configOpen, func() { text(c, "parallelism  2 → 4", 14) })
		ui.Divider(c)
		boxTitle(c, "本次排除 · 1 项")
		ui.Row(c).Gap(10).Children(func() { chip(c, "冲突"); text(c, "dbark / 测试环境说明", 14) })
		text(c, "解决冲突后，可在下次发布中纳入该记录。", 14)
		ui.Divider(c)
		text(c, "这 2 项的共享正文将以明文保存在此私有仓库的 Git 历史中。", 14)
		ui.Row(c).Gap(8).Justify(ui.End).Children(func() { ui.Button(c, "取消"); ui.PrimaryButton(c, "确认发布 2 项") })
	})
}
func (b board) frame(state string) *ui.Tester {
	n := 0
	for i, v := range boards {
		if v.file == b.file {
			n = i
		}
	}
	s := scenes[n]
	rescanned := state == "states/07-skills-rescanned"
	if rescanned {
		b.rows = append([][]string(nil), b.rows...)
		b.rows[0] = []string{"references/checks.md", "替换", "未修改"}
		s.state = "未修改"
		s.info = append([][2]string(nil), s.info...)
		s.info[len(s.info)-1] = [2]string{"本机副本", "与已安装版本一致"}
		s.facts = append([][2]string(nil), s.facts...)
		s.facts[2] = [2]string{"计划文件", "1 个新增 · 2 个替换"}
		s.desc = "重新扫描已完成，当前文件与已安装版本一致。可预览候选版本的改动。"
	}
	current := b.title
	if n == 3 {
		current = "项目"
	}
	if n == 2 {
		current = "同步"
	}
	sel := 0
	if n == 4 {
		sel = 1
	}
	ls := ui.ListState{Selected: &sel, RowHeight: 38}
	theme := ui.LightTheme().WithAccent(ui.Hex("#276550"))
	theme.FontSize = 14
	return ui.NewTester(func(c *ui.Context) {
		c.SetTheme(theme)
		ui.Row(c).Fill().AlignItems(ui.Stretch).Children(func() {
			ui.Column(c).Width(190).Background(pale).BorderWidth(0, 0, 1, 0).BorderColor(line).Padding(12, 10).Children(func() {
				ui.Row(c).Height(45).Gap(9).Padding(0, 6).Children(func() { ico(c, 9, 22); ui.Text(c, "CtxFerry").FontSize(22).Bold().TextColor(ink) })
				ui.Divider(c)
				ui.Sidebar(c, &current, func() {
					for _, g := range []struct {
						name string
						a, b int
					}{{"工作空间", 0, 2}, {"管理", 2, 6}, {"维护", 6, 7}} {
						ui.SidebarSection(c, g.name, nil, func() {
							for j := g.a; j < g.b; j++ {
								item := ui.SidebarItem(c, menu[j], icons[j], menu[j])
								if current == menu[j] {
									item.BorderWidth(0, 0, 0, 3).BorderColor(ink)
								}
							}
						})
					}
				}).Grow(1).FillWidth()
				ui.Divider(c)
				ui.Row(c).Padding(6).Gap(8).Children(func() {
					ico(c, 2, 16)
					ui.Column(c).Children(func() { ui.Text(c, "mac-mini").Bold(); small(c, "本机 · macOS · arm64") })
				})
			})
			ui.Column(c).Grow(1).Children(func() {
				ui.Row(c).Height(46).Padding(0, 24).Gap(12).Background(ui.Hex("#f9fbf9")).Children(func() {
					if n == 2 {
						ui.Button(c, "‹  返回同步")
					}
					small(c, "开发工作区")
					small(c, "/")
					text(c, strings.TrimPrefix(strings.TrimPrefix(b.context, "开发工作区 · "), "开发工作区  /  "), 14)
					ui.Spacer(c)
					ui.ButtonBase(c).Label("刷新本地视图").Tooltip("重新读取本机快照").Gap(5).Padding(5, 8).Radius(4).Background(pale).Children(func() { ico(c, 6, 14); text(c, "刷新本地视图", 14) })
					if n == 1 {
						ui.Box(c).Width(1).Height(20).Background(line)
						ui.Button(c, "检查远端").Tooltip("联网检查远端修订")

					}
				})
				ui.Divider(c)
				ui.Column(c).Padding(18, 24).Gap(5).Children(func() {
					ui.Text(c, b.title).FontSize(27).Bold().TextColor(ink)
					if n == 2 {
						small(c, "dbark   /   测试环境说明   ·   Context 文档")
					} else {
						small(c, s.sub)
					}
				})
				if n == 2 {
					ui.Divider(c)
					conflict(c)
					return
				}
				ui.Row(c).Margin(0, 24, 16, 24).Border(1, line).Radius(7).Padding(12, 15).Background(ui.Hex("#f5f8f5")).Gap(14).Children(func() {
					metrics := s.metrics[:]
					if n == 4 || n == 5 {
						metrics = append([][2]string{{"项目", "dbark"}}, metrics...)
					}
					if n == 6 {
						metrics = append([][2]string{{"项目", "dbark"}, {"Skill", "db-check"}}, metrics...)
					}
					if n == 0 {
						metrics = append(metrics, [2]string{"上次确认同步", "今天 14:32 · 7a4b102"})
					}
					for i, m := range metrics {
						ui.Column(c).Basis(0).Grow(1).Gap(2).Children(func() {
							ui.Text(c, m[0]).FontSize(14).TextColor(ink)
							if (n == 0 && (i == 1 || i == 2)) || (n == 1 && i < 2) {
								ui.Row(c).Height(29).Gap(8).Children(func() {
									ui.Text(c, strings.TrimSuffix(m[1], " 项")+" 项").FontSize(18).Bold().TextColor(ink)
									if n == 1 && m[0] == "待发布" {
										ui.Button(c, "预览发布…").Label("预览 2 项待发布变更").Tooltip("列出可发布的记录与排除的冲突")
									} else if n == 1 {
										ui.Button(c, "只看冲突").Label("仅显示" + m[0] + "记录")
									} else {
										ui.Button(c, "查看 ›").Label("查看" + m[0])
									}
								})
								return
							}
							if m[0] == "项目" {
								selectVal(c, "项目", m[1], "CtxFerry", "notes-kit", "所有项目")
								return
							}
							if n == 6 && m[0] == "Skill" {
								selectVal(c, "Skill", m[1], "ctxferry")
								return
							}
							if n == 6 && m[0] == "候选 pin" {
								selectVal(c, "候选 pin", m[1], "3ad021e")
								return
							}
							if n == 3 || n == 4 || n == 7 || n == 5 && m[0] == "资源" || n == 6 && m[0] == "安装目标" {
								selectVal(c, m[0], m[1])
								return
							}
							ui.Row(c).Height(29).AlignItems(ui.Center).Children(func() {
								size := float32(18)
								if n == 5 || n == 6 {
									size = 14
								}
								val := ui.Text(c, m[1]).FontSize(size).Bold().TextColor(ink)
								if n == 5 || n == 6 {
									val.Padding(3, 0, 0, 0)
								}
								if technical(m[1]) {
									val.Font("monospace")
								}
							})
						})
						if i+1 < len(metrics) {
							ui.Box(c).Width(1).Height(33).Background(line)
						}
					}
				})
				if n == 0 {
					ui.Row(c).Margin(0, 24, 14, 24).Padding(8, 12).Gap(10).Radius(6).Background(ui.Hex("#fbefea")).Children(func() {
						chip(c, "未解决冲突")
						text(c, "dbark 的「测试环境说明」在 mac-mini 与 legion / WSL 上分别修改。", 14)
						ui.Spacer(c)
						ui.Button(c, "比较版本").Label("比较 dbark 的测试环境说明")
					})
				}
				ui.Divider(c)
				if n == 3 {
					ui.Row(c).Padding(10, 24).Children(func() {
						tab := 3
						labels := []string{"Context", "资源", "Tasks", "配置", "Skills", "产物"}
						tabs := ui.SegmentedBase(c, &tab, len(labels))
						tabs.Track.Grow(1).Background(pale).Padding(2).Radius(5).Children(func() {
							for i, label := range labels {
								seg := tabs.Segment(i).Basis(0).Grow(1).Height(30).Justify(ui.Center).Label(label)
								if i == tab {
									seg.Background(ui.Hex("#e2efe7")).BorderWidth(0, 0, 2, 0).BorderColor(green)
								}
								seg.Children(func() {
									t := ui.Text(c, label).FontSize(14).TextColor(ink)
									if i == tab {
										t.Bold()
									}
								})
							}
						})
					})
					ui.Divider(c)
				}
				ui.Row(c).Grow(1).AlignItems(ui.Stretch).Children(func() {
					ui.Column(c).Grow(1).Padding(18, 24).Gap(12).Children(func() {
						ui.Row(c).Gap(10).Children(func() {
							boxTitle(c, b.section)
							if n == 6 {
								if rescanned {
									chip(c, "已重新扫描 · 0 项阻塞")
								} else {
									chip(c, "1 个文件有本地修改，更新已暂停")
								}
							}
							ui.Spacer(c)
							switch n {

							case 1:
								selectVal(c, "队列筛选", "全部记录", "冲突", "待发布")
							case 5:
								selectVal(c, "执行环境筛选", "所有执行环境", "仅本机环境")
							case 6:
								selectVal(c, "计划筛选", "所有变更", "本地修改")
							case 7:
								selectVal(c, "缓存状态", "全部状态", "仅元数据", "本机已缓存")
							}
							small(c, fmt.Sprintf("%d 项记录", len(b.rows)))
						})
						cols := []ui.TableColumn{{Title: b.cols[0]}, {Title: b.cols[1], Width: 142}, {Title: b.cols[2], Width: 133}}
						if n == 0 {
							cols = []ui.TableColumn{{Title: "项目"}, {Title: "配置方案", Width: 144}, {Title: "待发布", Width: 84}, {Title: "冲突", Width: 120}}
						}
						if n == 5 {
							cols = []ui.TableColumn{{Title: "执行环境"}, {Title: "系统", Width: 155}, {Title: "观察结果", Width: 127}, {Title: "观察时间", Width: 105}}
						}
						ui.Table(c, &ls, cols, len(b.rows), func(r, k int) {
							if n == 0 && k >= 2 {
								if (k == 2 && r < 2) || (k == 3 && r == 0) {
									if k == 2 {
										ui.Text(c, "1 项")
									} else {
										ui.Row(c).Children(func() { chip(c, "1 项冲突") })
									}
								} else {
									ui.Text(c, "0")
								}
								return
							}
							if n == 5 && k == 3 {
								if r == 0 {
									ui.Text(c, "今天 14:22").FontSize(13)
								} else {
									ui.Text(c, "未观察").FontSize(13)
								}
								return
							}
							val := b.rows[r][k]
							if k == 2 && n != 4 {
								ui.Row(c).Children(func() { chip(c, val) })
								return
							}
							if n == 4 && k == 1 {
								ui.Row(c).Children(func() { chip(c, val) })
								return
							}
							v := ui.Text(c, val).FontSize(14)
							if technical(val) {
								v.Font("monospace")
							}
						}).FillWidth().Height(float32(39*len(b.rows) + 44))
						if n == 4 {
							ui.Row(c).Gap(8).Padding(7, 10).Background(pale).Radius(5).Children(func() {
								ui.Column(c).Grow(1).Gap(3).Children(func() { small(c, "共享槽位"); text(c, "数据库凭据", 14) })
								ui.Column(c).Grow(1).Gap(3).Children(func() { small(c, "要求类型"); text(c, "连接字符串", 14) })
								ui.Column(c).Grow(1).Gap(3).Children(func() {
									small(c, "当前绑定")
									ui.Text(c, "test-db-reader").Font("monospace").FontSize(14).TextColor(ink)
								})

								ui.Button(c, "更换共享绑定…")
							})
						}
						ui.Divider(c)
						ui.Row(c).Gap(8).Children(func() {
							if n == 3 {
								boxTitle(c, "timeoutSeconds · 取值来源")
							} else {
								boxTitle(c, s.footTitle)
							}
							ui.Spacer(c)
							switch n {
							case 0:
								ui.Button(c, "管理本机认证")
							case 1:
								ui.Button(c, "备份与恢复…")

							case 4:
								ui.Button(c, "打开资源观察")
							case 6:

								ui.Button(c, "预览回滚…")
							case 7:
								ui.Button(c, "查看运行记录")
							}
						})
						if n == 3 {
							for _, v := range s.info {
								row := ui.Row(c).Gap(10).Padding(6, 8)
								if v[0] == "设备覆盖" {
									row.Background(pale)
								}
								row.Children(func() {
									ui.Text(c, v[0]).Width(100).FontSize(14).TextColor(ink)
									ui.Text(c, v[1]).Width(105).FontSize(14).TextColor(ink)
									switch v[0] {
									case "设备覆盖":
										ui.Text(c, "当前生效").Bold().TextColor(ink)
									case "项目":
										small(c, "恢复后生效")
									}
								})
							}
						} else {
							facts(c, s.facts)
						}
						if n == 6 {
							ui.Row(c).Gap(8).Children(func() {
								if rescanned {
									ui.PrimaryButton(c, "预览共享版本和 3 项文件变更…")
									small(c, "今天 14:42 已重新核对 3 个文件，等待确认。")
								} else {
									ui.Button(c, "重新扫描并生成计划").Label("重新生成整个更新计划").Tooltip("保留候选 pin，重新核对所有目标文件")
									text(c, "处理本地修改后重新扫描，即可预览 3 项变更。", 14)
								}
							})
						}
					})
					ui.Column(c).Width(327).Background(ui.Hex("#f7f9f7")).BorderWidth(0, 0, 0, 1).BorderColor(line).Padding(19).Gap(11).Children(func() {
						small(c, s.insKind)
						ui.Row(c).Gap(8).Children(func() {
							ico(c, []int{1, 7, 6, 8, 3, 2, 7, 5}[n], 19)
							v := ui.Text(c, s.insTitle).FontSize(21).Bold().TextColor(ink)
							if technical(s.insTitle) {
								v.Font("monospace")
							}
						})
						ui.Row(c).Children(func() { chip(c, s.state) })
						ui.Divider(c)
						if n == 3 {
							small(c, "配置写入层")
							selectVal(c, "配置写入层", "设备 · mac-mini", "项目", "配置方案", "Checkout")
							ui.PrimaryButton(c, "编辑设备层…").Label("编辑 mac-mini 的设备覆盖").FillWidth().Padding(8, 12)
						} else {
							facts(c, s.info)
						}
						ui.Divider(c)
						if n == 6 {
							small(c, "本机目标路径 · mac-mini")
							ui.Text(c, "~/Projects/dbark/.agents/skills/db-check/references/checks.md").Font("monospace").FontSize(13).TextColor(ink)
						}
						if n == 7 {
							small(c, "来源记录中的路径 · mac-mini")
							ui.Text(c, "/Users/dev/Projects/dbark/artifacts/integration-018/trace.zip").Font("monospace").TextColor(ink).FontSize(13)
						}
						text(c, s.desc, 14)
						if n == 3 {
							ui.Row(c).Gap(8).Padding(5, 0).Children(func() {
								text(c, "90 秒", 18)
								small(c, "→")
								ui.Text(c, "60 秒").FontSize(19).Bold().TextColor(green)
								small(c, "继承项目")
							})
						}
						if n == 5 {
							ui.Row(c).Gap(8).AlignItems(ui.Start).Children(func() {
								ico(c, 2, 16)
								ui.Column(c).Grow(1).Gap(4).Children(func() {
									small(c, "从 mac-mini 连接到")
									ui.Text(c, "db-test.example:5432").Font("monospace").FontSize(14).Bold().TextColor(ink)
								})
							})
						}
						if n == 3 {
							ui.Button(c, s.button).FillWidth().Padding(8, 12)
						} else if rescanned {
							ui.Button(c, s.button).Padding(8, 12).FillWidth()
						} else {
							ui.PrimaryButton(c, s.button).Padding(8, 12).FillWidth()
						}
						if n == 6 {
							ui.Button(c, "在文件夹中显示").Label("在 mac-mini 中显示 checks.md").FillWidth()
						}
						if n == 0 {
							ui.Button(c, "打开 dbark 项目").FillWidth()
						}
						if n == 4 {
							small(c, "登录完成后可重新检查条目可读性。")
						}
					})
				})
			})
		})
		if state == "states/02-sync-preview" {
			preview := true
			publishPreview(c, &preview)
		}
	}, 1280, 785)
}

type setupStep struct {
	file, device, os, journey, title, note string
	details                                [][2]string
	receipt, secondary, primary            string
}

var setupSteps = []setupStep{
	{"welcome", "mac-mini", "macOS · arm64", "设备接入", "设置这台设备", "先选择工作区的来源。已有私有同步仓库时，可以将资料拉取到这台设备。", nil, "", "", ""},
	{"checkout", "mac-mini", "macOS · arm64", "创建本地工作区", "绑定项目目录", "已识别所选 Git 工作树。请核对项目、路径和配置方案。", [][2]string{{"选择的目录", "~/Projects/dbark"}, {"识别结果", "Git 工作树 · dbark"}, {"配置方案", "development"}, {"写入范围", "mac-mini 的本地工作区"}}, "本地工作区已创建，目录尚未绑定。确认后将此目录绑定到 mac-mini。", "重新选择目录…", "绑定此目录"},
	{"private-remote", "legion / WSL", "Linux · x64", "加入已有工作区", "核对私有仓库", "已通过此设备的 Git 身份联网核验。确认目标后拉取资料。", [][2]string{{"Git 身份", "demo-reader"}, {"目标仓库", "github.com/demo/dev-workspace"}, {"可见性", "私有 · 已核验"}, {"同步分支", "main"}, {"远端修订", "7a4b102"}}, "本次将 main 分支的工作区共享记录及其 Git 历史拉到 legion / WSL。校验后再选订阅项目，以控制本机的索引、展示、Skill 安装范围和内容缓存。", "更换仓库…", "拉取并校验"},
	{"resume", "legion / WSL", "Linux · x64", "加入已有工作区", "继续上次接入", "上次关闭窗口前，已完成私有仓库核验和资料校验。", [][2]string{{"已保存", "今天 14:36 · 本机"}, {"已校验修订", "7a4b102 · main"}, {"目标仓库", "github.com/demo/dev-workspace"}, {"下一步", "选择订阅项目"}, {"后续步骤", "绑定本机 Checkout 和配置方案"}}, "Skills 安装和 Infisical 登录可稍后配置。", "查看已完成步骤", "继续选择订阅项目"},
	{"local-ready", "mac-mini", "macOS · arm64", "创建本地工作区", "本地工作区已就绪", "目录绑定已保存。可继续在本机使用，也可按需配置同步和其他能力。", [][2]string{{"项目与目录", "dbark · ~/Projects/dbark"}, {"配置方案", "development"}, {"Skills 引导", "已跳过"}, {"Infisical", "尚未登录"}, {"私人文档导入", "已跳过"}, {"远端同步", "尚未配置"}}, "进入项目后，可在设备总览查看本机能力和待配置项。", "配置可选能力…", "继续在本机使用"},
}

func setupFrame(step setupStep) *ui.Tester {
	theme := ui.LightTheme().WithAccent(green)
	theme.FontSize = 14
	return ui.NewTester(func(c *ui.Context) {
		c.SetTheme(theme)
		ui.Row(c).Fill().AlignItems(ui.Stretch).Children(func() {
			ui.Column(c).Width(190).Padding(12, 10).Gap(12).BorderWidth(0, 0, 1, 0).BorderColor(line).Background(pale).Children(func() {
				ui.Row(c).Height(45).Gap(9).Padding(0, 6).Children(func() { ico(c, 9, 22); ui.Text(c, "CtxFerry").FontSize(22).Bold().TextColor(ink) })
				ui.Divider(c)
				boxTitle(c, step.journey)
				if step.file != "welcome" {
					labels := []string{"选择来源", "绑定目录", "可选配置", "本机就绪"}
					active := 1
					if step.file == "local-ready" {
						active = 3
					}
					if step.journey == "加入已有工作区" {
						labels = []string{"选择来源", "核对仓库", "拉取与校验", "订阅项目", "绑定本机目录"}
						if step.file == "resume" {
							active = 3
						}
					}
					ui.Column(c).Gap(5).Children(func() {
						for i, label := range labels {
							status, mark := "未开始", "○"
							if i < active {
								status, mark = "已完成", "✓"
							}
							if step.file == "local-ready" && label == "可选配置" {
								status, mark = "已跳过", "–"
							}
							if i == active {
								status, mark = "当前", "●"
								if step.file == "resume" {
									status, mark = "待继续", "›"
								}
							}
							if step.file == "local-ready" && i == active {
								status, mark = "已就绪", "✓"
							}
							row := ui.Row(c).Padding(7, 6).Gap(6)
							if i == active {
								row.Background(ui.Hex("#dcebe3")).Radius(4)
							}
							row.Children(func() { small(c, mark); text(c, label, 14); ui.Spacer(c); small(c, status) })
						}
					})
				}
				ui.Spacer(c)
				ui.Divider(c)
				ui.Row(c).Gap(8).Children(func() {
					ico(c, 2, 16)
					ui.Column(c).Gap(2).Children(func() { ui.Text(c, step.device).Bold(); small(c, "本机 · "+step.os) })
				})
			})
			ui.Column(c).Grow(1).Children(func() {
				ui.Row(c).Height(46).Padding(0, 24).Gap(10).Background(ui.Hex("#f9fbf9")).Children(func() {
					small(c, "接入工作区")
					if step.file != "welcome" {
						small(c, "/")
						text(c, step.journey, 14)
					}
					ui.Spacer(c)
					if step.file == "resume" {
						ui.Button(c, "重新选择来源…").Tooltip("选择新来源前先确认，当前进度已保存")
						ui.Button(c, "稍后继续")
					} else if step.file != "welcome" && step.file != "local-ready" {
						ui.Button(c, "返回选择来源")
						ui.Button(c, "保存进度并退出")
					}
				})
				ui.Divider(c)
				if step.file == "local-ready" {
					ui.Column(c).Grow(1).AlignItems(ui.Center).Justify(ui.Center).Children(func() {
						ui.Column(c).Width(620).Padding(24).Gap(10).Border(1, line).Radius(9).Children(func() {
							ui.Row(c).Gap(9).Children(func() { ico(c, 2, 22); ui.Text(c, step.title).FontSize(27).Bold().TextColor(ink) })
							text(c, step.note, 14)
							ui.Divider(c)
							facts(c, step.details)
							ui.Divider(c)
							ui.Row(c).Gap(10).Children(func() { ui.PrimaryButton(c, step.primary); ui.Button(c, step.secondary) })
						})
					})
					return
				}
				ui.Column(c).Padding(18, 24).Gap(12).Children(func() {
					ui.Text(c, step.title).FontSize(27).Bold().TextColor(ink)
					small(c, step.note)
					if step.file == "welcome" {
						ui.Row(c).Gap(14).AlignItems(ui.Stretch).Children(func() {
							for i, option := range []string{"创建本地工作区", "加入已有工作区"} {
								ui.Column(c).Grow(1).Basis(0).Border(1, line).Radius(8).Padding(20).Gap(14).Children(func() {
									ui.Row(c).Gap(8).Children(func() { ico(c, []int{1, 6}[i], 20); boxTitle(c, option) })
									small(c, []string{"从本机已有的项目目录开始，稍后可开启同步。", "核对已有私有仓库，然后选择要订阅的项目。"}[i])
									ui.Row(c).Children(func() { ui.Button(c, []string{"从本机目录开始…", "选择私有仓库…"}[i]) })
								})
							}
						})
						return
					}
					ui.Row(c).Gap(16).AlignItems(ui.Start).Children(func() {
						ui.Column(c).Basis(0).Grow(2).Border(1, line).Radius(8).Padding(16, 20).Children(func() {
							if step.file != "checkout" {
								facts(c, step.details)
								return
							}
							for _, pair := range step.details {
								if pair[0] == "配置方案" {
									ui.Row(c).Gap(10).Padding(7, 0).AlignItems(ui.Center).Children(func() {
										ui.Text(c, "配置方案").FontSize(13).Width(92).TextColor(mute)
										selectVal(c, "所选目录的配置方案", pair[1], "default")
									})
								} else {
									facts(c, [][2]string{pair})
								}
							}
						})
						ui.Column(c).Basis(0).Grow(1).Gap(12).Padding(16).Background(pale).Radius(8).Children(func() {
							boxTitle(c, map[string]string{"resume": "恢复接入", "private-remote": "拉取范围", "checkout": "本次绑定", "local-ready": "下一步"}[step.file])

							if step.file == "resume" || step.file == "local-ready" {
								ui.Row(c).Children(func() { chip(c, "进度已保存") })
							}
							text(c, step.receipt, 15)
							ui.PrimaryButton(c, step.primary).FillWidth()
							ui.Button(c, step.secondary).FillWidth()
						})
					})
				})
			})
		})
	}, 1280, 785)
}

func main() {
	for _, p := range paths {
		icons = append(icons, ui.MustParseSVG([]byte(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="`+p+`" fill="none" stroke="black" stroke-width="1.7"/></svg>`)))
	}
	for _, b := range boards {
		names := []string{b.file}
		if b.file == "02-sync" {
			names = append(names, "states/02-sync-preview")
		}
		if b.file == "07-skills" {
			names = append(names, "states/07-skills-rescanned")
		}
		for _, name := range names {
			tt := b.frame(name)
			saveFrame(tt, name)
		}
	}
	for _, step := range setupSteps {
		saveFrame(setupFrame(step), "states/setup-"+step.file)
	}
}
func saveFrame(tt *ui.Tester, name string) {
	tt.SetScale(1.5)
	path := filepath.Join(os.Args[1], name+".png")
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		panic(err)
	}
	f, e := os.Create(path)
	if e != nil {
		panic(e)
	}
	if e = png.Encode(f, tt.Image()); e != nil {
		panic(e)
	}
	f.Close()
	fmt.Println(name)
}
